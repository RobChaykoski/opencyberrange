# Karate upload fixture
